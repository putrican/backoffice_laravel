<?php $__env->startSection('container'); ?>
    <form action="<?php echo e(route('orders.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h1>Mata Uang</h1>
                        <nav class="breadcrumb-container d-none d-sm-block d-lg-inline-block" aria-label="breadcrumb">
                            <ol class="breadcrumb pt-0">
                                <li class="breadcrumb-item">
                                    <a href="/dashboard">Home</a>
                                </li>
                            </ol>
                        </nav>
                        <div class="separator mb-5"></div>
                    </div>
                </div>
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <div class="container">
                                <div class="row">
                                    
                                    <div class="col-md-6 col-sm-12 col-lg-6">
                                        <div class="form-group">
                                            <h6 class="font-weight-bold">Mata Uang</h6>
                                            <select class="custom-select <?php $__errorArgs = ['mata_uang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="mata_uang" value="<?php echo e(old('mata_uang')); ?>"
                                                placeholder="Masukkan Kurs">
                                                <option value="¥">¥ </option>
                                                <option value="$">$</option>
                                                <option value="Rp">Rp</option>                                           
                                            </select>
                                            <?php $__errorArgs = ['mata_uang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger mt-2">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-12 col-lg-6">
                                        <div class="form-group ">
                                            <h6 class="font-weight-bold">NILAI</h6>

                                            <input type="text" id="nilai" onkeyup="sum();"
                                                class="form-control  <?php $__errorArgs = ['nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                type-currency="IDR" name="nilai"
                                                value="<?php echo e(old('nilai')); ?>" placeholder="Masukkan Nilai">
                                            <?php $__errorArgs = ['nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger mt-2">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                </div>
                                
                            </div>
                            <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
                            
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>

    <script>
        function getKurs(selectObject) {
            var value = selectObject.value;
            if (value == 'Rp') {
                let hasil = document.getElementById("hasil").value;
                document.getElementById("rate_kurs").value = hasil

                let hasil1 = document.getElementById("hasil").value;
                document.getElementById("harga_kurs").value = hasil1
            }
            console.log(value);
        }
    </script>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravelv8/resources/views/kurs/create.blade.php ENDPATH**/ ?>