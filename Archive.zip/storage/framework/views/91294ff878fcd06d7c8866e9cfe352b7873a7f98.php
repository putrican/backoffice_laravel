<?php $__env->startSection('container'); ?>

    <div class="container">
            <div class="card-body">
            <div class="row">
                <div class="col-4">
                    
                </div>
            </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <br>
            <?php if(session('edit')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('edit')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-responsive" >
                    <thead>
                        <tr>
                            <th scope="col" class="text-center">No</th>
                            <th scope="col" class="text-center">Mata Uang</th>
                            <th scope="col" class="text-center">Nilai</th>
                            <th scope="col" class="text-center">Action</th>

                        </tr>
                    </thead>
                  
                </table>
            </div>

            </div>
        </div>
    </div>

     

<?php $__env->stopSection(); ?>
<script>
    function getKurs(selectObject) {
        var value = selectObject.value;
        if (value == 'Rp') {
            let hasil = document.getElementById("approve_price").value;
            document.getElementById("rate_kurs_a").value = hasil

            let hasil1 = document.getElementById("approve_price").value;
            document.getElementById("harga_kurs_a").value = hasil1
        }
        console.log(value);
    }
    setTimeout(function(){
        $(".alert").remove();
    },3000);
</script>
    
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravelv8/resources/views/kurs/index.blade.php ENDPATH**/ ?>