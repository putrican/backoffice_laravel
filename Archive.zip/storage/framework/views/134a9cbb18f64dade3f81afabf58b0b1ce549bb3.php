<?php $__env->startSection('container'); ?>


    <div class="container-fluid">
        <div class="col-lg-12 col-md-12 mb-4">
            <div class="card">
                <div class="card-body">               
                    <div class="row">
                        <div class="col-4">
                            <a href="<?php echo e(route('kurs.create')); ?>" class="btn btn-outline-primary mb-2"><i
                                    class="simple-icon-docs"></i>
                                Add Mata Uang </a>
                        </div>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-stripped">
                            <thead>
                                <tr class="header">
                                    <th scope="col" class="text-center">No</th>
                                    <th scope="col" class="text-center">Mata Uang</th>
                                    <th scope="col" class="text-center">Nilai</th>
                                    <th scope="col" class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $curs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                        <td class="text-center"><?php echo e($curs->mata_uang); ?></td>
                                        <td class="text-center"><?php echo e(number_format($curs->nilai)); ?></td>
                                        <td class="text-center"><a href="/dashboard/kurs/edit/<?php echo e($curs->id); ?>"
                                                class="btn btn-outline-primary"><i
                                                    class="glyph-icon iconsminds-file-edit"></i></a></td>

                                        


                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="alert alert-danger">
                                            Data belum Tersedia.
                                        </div>
                                <?php endif; ?>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->stopSection(); ?>
    <script>
        function getKurs(selectObject) {
            var value = selectObject.value;
            if (value == 'Rp') {
                let hasil = document.getElementById("approve_price").value;
                document.getElementById("rate_kurs_a").value = hasil

                let hasil1 = document.getElementById("approve_price").value;
                document.getElementById("harga_kurs_a").value = hasil1
            }
            console.log(value);
        }
        setTimeout(function() {
            $(".alert").remove();
        }, 3000);
    </script>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravelv8/resources/views/dashboard/kurs/index.blade.php ENDPATH**/ ?>