<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1>Form Order</h1>
                <nav class="breadcrumb-container d-none d-sm-block d-lg-inline-block" aria-label="breadcrumb">
                    <ol class="breadcrumb pt-0">
                        <li class="breadcrumb-item">
                            <a href="/dashboard">Home</a>
                        </li>
                 
                    </ol>
                </nav>
                <div class="separator mb-5"></div>
            </div>

            <div class="row mb-4">
                <div class="col-lg-12 col-md-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <div class=col-12>
                                <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-outline-primary mb-2"><i
                                        class="simple-icon-docs"></i>
                                    NEW FORM ORDER </a>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-responsive" id="categoryTbl">
                                <thead>
                                    <tr>
                                        <th scope="col" class="text-center">No</th>
                                        <th scope="col" class="text-center">Marketing</th>
                                        <th scope="col" class="text-center">Marking</th>
                                        <th scope="col" class="text-center">Item</th>
                                        <th scope="col" class="text-center">Total</th>
                                        <th scope="col" class="text-center">Total Invoice</th>
                                        <th scope="col" class="text-center">Keterangan</th>
                                        <th scope="col" class="text-center">Approve Price</th>
                                        <th scope="col" class="text-center">No.BL/No.Cont</th>
                                        <th scope="col" class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td class="text-center "><?php echo e($loop->iteration); ?></td>
                                            <td class="text-center"><?php echo e($order->marketing); ?></td>
                                            <td class="text-center"><?php echo e($order->marking); ?></td>
                                            <td class="text-center"><?php echo e($order->item); ?><br><?php echo e($order->qty); ?> x
                                                <?php echo e($order->size); ?><br><span
                                                    class="text1"><?php echo e($order->asal); ?></span>=><span
                                                    class="text2"><?php echo e($order->port); ?></span></td>
                                            <td class="text-left">Rp.<?php echo e(number_format($order->total)); ?>

                                                <div class="container">
                                                    <p type="" id="text-right" data-toggle="collapse"
                                                        data-target="#demo<?php echo e($order->id); ?>">
                                                        Details.</p>
                                                    <div id="demo<?php echo e($order->id); ?>" class="collapse">
                                                        <span class="text3">
                                                            <p class="text5">Harga Custom: </p>
                                                            Rp.<?php echo e(number_format($order->harga_custom)); ?>

                                                        </span>
                                                        <span class="text3">
                                                            <p class="text5">Harga Kapal: </p>
                                                            Rp.<?php echo e(number_format($order->harga_kapal)); ?>

                                                        </span>
                                                        <span class="text3">
                                                            <p class="text5">Harga Gudang: </p>
                                                            Rp.<?php echo e(number_format($order->harga_gudang)); ?>

                                                        </span>
                                                        <?php if($role == 'Admin'): ?>
                                                            <span>
                                                                <p class="text5">Keterangan: </p>
                                                                <?php echo e($order->keterangan_approve); ?>

                                                            </span>
                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <?php echo e($order->curs->mata_uang ?? ''); ?><?php echo e(number_format($order->total_invoice_rmb)); ?><br><br>Rp.<?php echo e(number_format($order->rate_kurs)); ?>

                                            </td>
                                            <td class="text-center"><?php echo e($order->keterangan); ?></span></td>
                                            <td class="text-center">
                                                <?php if($order->approve > 0): ?>
                                                    <span
                                                        class="text-success"><?php echo e(number_format($order->approve)); ?></span><br><br><span
                                                        class="text-success">Rp.<?php echo e(number_format($order->rate_kurs_a)); ?></span>
                                                <?php else: ?>
                                                    <span><?php echo e(number_format($order->approve)); ?></span><br><br><span>Rp.<?php echo e(number_format($order->rate_kurs)); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center"><?php echo e($order->no_bl); ?>/<?php echo e($order->no_cont); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <div class="dropdown d-inline-block">
                                                        <button class="btn btn-outline-primary dropdown-toggle mb-1"
                                                            type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                                            aria-haspopup="true" aria-expanded="false">
                                                            Action
                                                        </button>
                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                            <button type="button" class="dropdown-item"
                                                                data-toggle="modal"
                                                                data-target="#modalFile<?php echo e($order->id); ?>">Upload PL
                                                                <li><a href="<?php echo e(asset($order->file)); ?>"><i
                                                                            class="iconsminds-download-1"></i>Download</a>
                                                                </li>
                                                            </button>
                                                            <a class="dropdown-item"
                                                                href="/dashboard/orders/edit/<?php echo e($order->id); ?>">Edit</a>
                                                            <?php if($role == 'Admin'): ?>
                                                                <button type="button" class="dropdown-item"
                                                                    data-toggle="modal"
                                                                    data-target="#modalApprove<?php echo e($order->id); ?>">
                                                                    Approve Price
                                                                </button>
                                                            <?php else: ?>
                                                            <?php endif; ?>
                                                            <button type="button" class="dropdown-item" data-toggle="modal"
                                                                data-target="#modalCont<?php echo e($order->id); ?>">
                                                                No Cont/No BL
                                                            </button>
                                                            <button type="button" class="dropdown-item" data-toggle="modal"
                                                                data-target="#exampleModal1<?php echo e($order->id); ?>">
                                                                Final PL
                                                                <a href="<?php echo e(asset($order->final)); ?>"><br><i
                                                                        class="iconsminds-download-1"></i>Download</a><br>
                                                            </button>
                                                        </div>
                                                        
                                                        <div class="modal fade" id="modalFile<?php echo e($order->id); ?>"
                                                            tabindex="-1" role="dialog" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <div class="container mt-5">
                                                                            <form
                                                                                action="<?php echo e(route('orders.viewFileUpload', $order->id)); ?>"
                                                                                method="POST"
                                                                                enctype="multipart/form-data">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php echo method_field('PATCH'); ?>

                                                                                <div class="container">
                                                                                    <h5 class="text-center">Please Upload
                                                                                        File
                                                                                        Packing
                                                                                        List
                                                                                    </h5>
                                                                                    <div class="custom-file mt-5">
                                                                                        <input type="file"
                                                                                            name="file"
                                                                                            class="custom-file-input"
                                                                                            id="chooseFile">
                                                                                        <label class="custom-file-label"
                                                                                            for="chooseFile">Choose
                                                                                            File</label>
                                                                                    </div>
                                                                                    <hr>
                                                                                    <button type="submit" name="submit"
                                                                                        class="btn btn-primary">Upload
                                                                                        File</button>
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Modal Approve Price-->
                                                        <div class="modal fade" id="modalApprove<?php echo e($order->id); ?>"
                                                            tabindex="-1" role="dialog" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close"
                                                                            data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <div class="container mt-5">
                                                                            <form
                                                                                action="<?php echo e(route('orders.approve', $order->id)); ?> "
                                                                                method="POST"
                                                                                enctype="multipart/form-data">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php echo method_field('POST'); ?>

                                                                                <div class="container">
                                                                                    <div class="row">
                                                                                        <div class="col-3">
                                                                                            <div class="form-group">
                                                                                                <h6
                                                                                                    class="font-weight-bold">
                                                                                                    KURS
                                                                                                </h6>
                                                                                                <select
                                                                                                    class="custom-select <?php $__errorArgs = ['kurs_a '];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                                    id="mySelects<?php echo e($order->id); ?>"
                                                                                                    onchange="kali_1(<?php echo e($order->id); ?>)"
                                                                                                    name="kurs_a"
                                                                                                    value="<?php echo e(old('kurs_a')); ?>">

                                                                                                    <?php $__currentLoopData = $curs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cursa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                        <option
                                                                                                            value="<?php echo e($cursa->nilai); ?>">
                                                                                                            <?php echo e($cursa->mata_uang); ?>

                                                                                                        </option>
                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                                                </select>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="col-9">
                                                                                            <div class="form-group">
                                                                                            <h6 class="font-weight-bold">APPROVE PRICE</h6>
                                                                                            <input type="text"
                                                                                                id="approve_price<?php echo e($order->id); ?>"
                                                                                                onkeyup="kali_1(<?php echo e($order->id); ?>);"
                                                                                                class="form-control approve <?php $__errorArgs = ['approve'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                                name="approve"
                                                                                                value="<?php echo e(old('approve')); ?>"
                                                                                                placeholder="Masukkan Approve Price">
                                                                                        </div>
                                                                                    </div>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="col-12">
                                                                                            <div class="form-group">
                                                                                        <h6 class="font-weight-bold">RATE
                                                                                        </h6>
                                                                                        <input type="text"
                                                                                            id="rate_kurs_a<?php echo e($order->id); ?>"
                                                                                            onkeyup="kali_1();" readonly
                                                                                            class="form-control <?php $__errorArgs = ['rate_kurs_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            type-currency="IDR"
                                                                                            name="rate_kurs_a"
                                                                                            value="<?php echo e(old('rate_kurs_a')); ?>"
                                                                                            onkeydown="return numbersonly(this, event);"
                                                                                            onkeyup="javascript:tandaPemisahTitik(this);">
                                                                                        <?php $__errorArgs = ['rate_kurs_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                            <div
                                                                                                class="alert alert-danger mt-2">
                                                                                                <?php echo e($message); ?>

                                                                                            </div>
                                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="col-12">
                                                                                        <h6 class="font-weight-bold">
                                                                                                KETERANGAN</h6>
                                                                                            <div class="form-group">
                                                                                                <input type="text"
                                                                                                    class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                                    name="keterangan"
                                                                                                    value="<?php echo e(old('keterangan')); ?>"
                                                                                                    placeholder="Masukkan keterangan ">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="col-12">
                                                                                        <button type="submit"                                                                                   <button type="submit"
                                                                                            name="submit"
                                                                                            class="btn btn-primary btn-block mt-4">
                                                                                            Save
                                                                                        </button>
                                                                                        </div>
                                                                                    </div>

                                                                                                                                                                 
                                                                                </div>

                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                                                                            
                                                        <div class="modal fade" id="exampleModal1<?php echo e($order->id); ?>"
                                                            tabindex="-1" role="dialog" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <div class="container mt-5">
                                                                            <form
                                                                                action="<?php echo e(route('orders.viewFinalUpload', $order->id)); ?>"
                                                                                method="POST"
                                                                                enctype="multipart/form-data">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php echo method_field('PATCH'); ?>

                                                                                <div class="container">
                                                                                    <h5 class="text-center">Please Upload
                                                                                        Final
                                                                                        Packing
                                                                                        List</h5>
                                                                                    <div class="custom-file mt-5">
                                                                                        <input type="file"
                                                                                            name="file"
                                                                                            class="custom-file-input"
                                                                                            id="chooseFile">
                                                                                        <label class="custom-file-label"
                                                                                            for="chooseFile">Choose
                                                                                            File</label>
                                                                                    </div>
                                                                                    <hr>
                                                                                    <button type="submit" name="submit"
                                                                                        class="btn btn-primary">Upload
                                                                                        File</button>
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>                                                    
                                                        
                                                        <div class="modal fade" id="modalCont<?php echo e($order->id); ?>"
                                                            tabindex="-1" role="dialog" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                            
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close"
                                                                            data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <div class="container mt-5">
                                                                            <form
                                                                                action="<?php echo e(route('orders.cont', $order->id)); ?>"
                                                                                method="POST"
                                                                                enctype="multipart/form-data">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php echo method_field('POST'); ?>
                                                                                <div class="container">
                                                                                    <div class="row">
                                                                                        <div class="col-md-12">
                                                                                            <h3 class="text-left">No BL
                                                                                            </h3>
                                                                                            <div class="form-group">
                                                                                                <input type="text"
                                                                                                    class="form-control <?php $__errorArgs = ['no_bl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                                    name="no_bl"
                                                                                                    value="<?php echo e(old('no_bl')); ?>"
                                                                                                    placeholder="Masukkan No BL">
                                                                                                <?php $__errorArgs = ['no_bl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                    <div
                                                                                                        class="alert alert-danger mt-3">
                                                                                                        <?php echo e($message); ?>

                                                                                                    </div>
                                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="col-md-12">
                                                                                            <h3 class="text-left">No Cont
                                                                                            </h3>
                                                                                            <div class="form-group">
                                                                                                <input type="text"
                                                                                                    class="form-control <?php $__errorArgs = ['no_cont'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                                    name="no_cont"
                                                                                                    value="<?php echo e(old('no_cont')); ?>"
                                                                                                    placeholder="Masukkan no cont">

                                                                                                <?php $__errorArgs = ['no_cont'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                    <div
                                                                                                        class="alert alert-danger mt-3">
                                                                                                        <?php echo e($message); ?>

                                                                                                    </div>
                                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="col-4">
                                                                                            <button type="submit"
                                                                                                name="submit"
                                                                                                class="btn btn-primary btn-block mt-4">
                                                                                                Save
                                                                                            </button>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>                                                                                     
                                                    </div>
                                                </div>
                                            </td>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <div class="alert alert-danger">
                                                Data belum Tersedia.
                                            </div>
                                    <?php endif; ?>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#categoryTbl').DataTable({
                dom: '<"top"fB>rts<"buttom"r><"clear">'

            });
        });
    </script>
<?php $__env->stopPush(); ?>

<script>
    function kali_1(data) {
        var d = document.getElementById('mySelects'+data).value;
        var hKursA = parseInt(d.replaceAll(',', ''))

        var e = document.getElementById('approve_price'+data).value;
        var hApprove = parseInt(e.replaceAll(',', ''))

        var result = parseInt(hKursA) * parseInt(hApprove);

        if (!isNaN(result)) {
            document.getElementById('rate_kurs_a'+data).value = result;
        }
    }

    setTimeout(function() {
        $(".alert").remove();
    }, 3000);
</script>



<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravelv8/resources/views/dashboard/orders/index.blade.php ENDPATH**/ ?>