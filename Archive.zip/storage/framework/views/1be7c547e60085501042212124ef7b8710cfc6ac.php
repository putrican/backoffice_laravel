<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>BLUERAY Cargo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/font/iconsmind-s/css/iconsminds.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/font/simple-line-icons/css/simple-line-icons.css" />

    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/css/vendor/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/css/vendor/bootstrap.rtl.only.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/css/vendor/component-custom-switch.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/css/vendor/perfect-scrollbar.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/css/main.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/css/dore.light.bluenavy.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/css1/style.css" />
  
</head>
<body id="app-container" class="menu-sub-hidden show-spinner">
    <nav class="navbar fixed-top">
        <div class="d-flex align-items-center navbar-left">
            <a href="#" class="menu-button d-none d-md-block">
                <svg class="main" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9 17">
                    <rect x="0.48" y="0.5" width="7" height="1" />
                    <rect x="0.48" y="7.5" width="7" height="1" />
                    <rect x="0.48" y="15.5" width="7" height="1" />
                </svg>
                <svg class="sub" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 17">
                    <rect x="1.56" y="0.5" width="16" height="1" />
                    <rect x="1.56" y="7.5" width="16" height="1" />
                    <rect x="1.56" y="15.5" width="16" height="1" />
                </svg>
            </a>

            <a href="#" class="menu-button-mobile d-xs-block d-sm-block d-md-none">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 17">
                    <rect x="0.5" y="0.5" width="25" height="1" />
                    <rect x="0.5" y="7.5" width="25" height="1" />
                    <rect x="0.5" y="15.5" width="25" height="1" />
                </svg>
            </a>

            

           
        </div>
        <a class="navbar-logo" href="Dashboard.Default.html">
            <span class="logo d-none d-xs-block"></span>
            <span class="logo-mobile d-block d-xs-none"></span>
        </a>

        <div class="navbar-right">
            <div class="header-icons d-inline-block align-middle">



                <button class="header-icon btn btn-empty d-none d-sm-inline-block" type="button" id="fullScreenButton">
                    <i class="simple-icon-size-fullscreen"></i>
                    <i class="simple-icon-size-actual"></i>
                </button>

            </div>

            <div class="user d-inline-block">
               
                  <ul class="navbar-nav ms-auto">
              <?php if(auth()->guard()->check()): ?>
                     <li class="nav-item dropdown">
                         <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                             aria-expanded="false">
                             Welcome back, <?php echo e(auth()->user()->name); ?>

                         </a>
                         <ul class="dropdown-menu">
                             <li><a class="dropdown-item" href="/dashboard"><i class="bi bi-layout-text-window-reverse"></i> My dashboard</a></li>
                             <li><hr class="dropdown-divider"></li>
                             <li>
                                <form action="/logout" method="post">
                                <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item"><i class="bi bi-box-arrow-in-right"></i> Logout</a></li>
                                    </button>
                                </form>
                             </li>
                         </ul>
                     </li>
                 <?php else: ?>
                     <li class="nav-item">
                         <a href="/login" class="nav-link"><i class="bi bi-box-arrow-in-right"></i>Login</a>
                     </li>

                 <?php endif; ?>

             </ul>

            </div>
        </div>
    </nav>
    <div class="menu">
        <div class="main-menu">
            <div class="scroll">
                <ul class="list-unstyled">
                    <li>
                        <a href="#dashboard">
                            <i class="iconsminds-shop-4"></i>
                            <span>Dashboards</span>
                        </a>
                    </li>
                 
                </ul>
            </div>
        </div>

        <div class="sub-menu">
            <div class="scroll">
                <ul class="list-unstyled" data-link="dashboard">
                    <li>
                        <a href="/dashboard/orders/index">
                            <i class="simple-icon-rocket"></i> <span class="d-inline-block">Form Order</span>
                        </a>
                    </li>
                </ul>
                
                
                

                

            </div>
        </div>
    </div>
    <main>
        <?php echo $__env->yieldContent('container'); ?>
    </main>

    <footer class="page-footer">
        <div class="footer-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-sm-6">
                        <p class="mb-0 text-muted">ColoredStrategies 2022</p>
                    </div>
                    <div class="col-sm-6 d-none d-sm-block">
                        <ul class="breadcrumb pt-0 pr-0 float-right">
                            <li class="breadcrumb-item mb-0">
                                <a href="#" class="btn-link">Review</a>
                            </li>
                            <li class="breadcrumb-item mb-0">
                                <a href="#" class="btn-link">Purchase</a>
                            </li>
                            <li class="breadcrumb-item mb-0">
                                <a href="#" class="btn-link">Docs</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="<?php echo e(URL::to('/')); ?>/js/vendor/jquery-3.3.1.min.js"></script>
    <script src="<?php echo e(URL::to('/')); ?>/js/vendor/mousetrap.min.js"></script>
    <script src="<?php echo e(URL::to('/')); ?>/js/vendor/perfect-scrollbar.min.js"></script>
    <script src="<?php echo e(URL::to('/')); ?>/js/dore.script.js"></script>
    <script src="<?php echo e(URL::to('/')); ?>/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(URL::to('/')); ?>/js/scripts.js"></script>
</body>

</html><?php /**PATH /Users/user/Documents/laravelv8/resources/views/dashboard/layouts/main.blade.php ENDPATH**/ ?>