<?php $__env->startSection('container'); ?>
    

    <div class="container ">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-md btn-success mb-3">ADD FORM ORDER</a>
                        <?php if(session('edit')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('edit')); ?>

                            </div>
                        <?php endif; ?>
                        <div style="overflow-x:auto;">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">MARKETING</th>
                                        <th scope="col">MARKING</th>
                                        <th scope="col">ITEM</th>
                                        <th scope="col">SIZE</th>
                                        <th scope="col">QTY</th>
                                        <th scope="col">H.CUSTOM</th>
                                        <th scope="col">H.KAPAL</th>
                                        <th scope="col">H.GUDANG</th>
                                        <th scope="col">TOTAL</th>
                                        <th scope="col">ASAL</th>
                                        <th scope="col">PORT</th>
                                        <th scope="col">TOTAL INVOICE RMB</th>
                                        <th scope="col">STATUS</th>
                                        <th scope="col">FILE</th>
                                        <th scope="col">ACTION</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($order->marketing); ?></td>
                                            <td><?php echo e($order->marking); ?></td>
                                            <td><?php echo e($order->item); ?></td>
                                            <td><?php echo e($order->size); ?></td>
                                            <td><?php echo e($order->qty); ?></td>
                                            <td><?php echo e($order->harga_custom); ?></td>
                                            <td><?php echo e($order->harga_kapal); ?></td>
                                            <td><?php echo e($order->harga_gudang); ?></td>
                                            <td><?php echo e($order->total); ?></td>
                                            <td><?php echo e($order->asal); ?></td>
                                            <td><?php echo e($order->port); ?></td>
                                            <td><?php echo e($order->total_invoice_rmb); ?></td>
                                            <td><?php echo e($order->keterangan); ?></td>
                                            <td><?php echo e($order->upload); ?></td>
                                            <td>
                                                <div class="btn-group">

                                                    <div class="dropdown d-inline-block">
                                                        <button class="btn btn-outline-primary dropdown-toggle mb-1"
                                                            type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                                            aria-haspopup="true" aria-expanded="false">
                                                            Action
                                                        </button>
                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                            
                                                            <button class="dropdown-item" onclick="uploadPackingList()">Upload
                                                                Packing List</button>
                                                            <a class="dropdown-item"
                                                                href="/dashboard/orders/edit/<?php echo e($order->id); ?>">Edit </a>
                                                            <button class="dropdown-item" onclick="approveHarga()">Approve
                                                                Harga</button>
                                                            <button class="dropdown-item" onclick="findPackingList()">Find
                                                                Packing List</button>
                                                           
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                  
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="alert alert-danger">
                                            Data Blog belum Tersedia.
                                        </div>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>






    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    
    <script>
        function uploadPackingList() {
            alert("Upload Packing List");
        }

        function approveHarga() {
            alert("Approve Harga");
        }

        function findPackingList() {
            alert("Find Packing List");
        }
    </script>

    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/user/Documents/laravelv8/resources/views/dashboard/orders/index.blade.php ENDPATH**/ ?>