<?php $__env->startSection('container'); ?>
    <form action="<?php echo e(route('orders.store')); ?>" method="POST" enctype="multipart/form-data" name="crt">
        <?php echo csrf_field(); ?>
        <div class="row mb-4">
            <div class="col-lg-8 col-md-8 mb-4">
                <div class="card">
                    <div class="card-body">
                        <div class=col-12>
                            <div class="container">
                                <div class="row">
                                    <div class="col-12">
                                        <h1>Add Form Order</h1>
                                        <nav class="breadcrumb-container d-none d-sm-block d-lg-inline-block"
                                            aria-label="breadcrumb">
                                            <ol class="breadcrumb pt-0">
                                                <li class="breadcrumb-item">
                                                    <a href="/dashboard">Home</a>
                                                </li>

                                            </ol>
                                        </nav>
                                        <div class="separator mb-5"></div>
                                    </div>
                                </div>


                                <div class="card border-0 shadow rounded">
                                    <div class="card-body">
                                        
                                        <div class="container">
                                            <div class="">
                                                <div class="row">
                                                    <div class="col-md-6 col-sm-12 col-lg-6">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">MARKETING</h6>
                                                            <select
                                                                class="custom-select <?php $__errorArgs = ['marketing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="marketing" value="<?php echo e(old('marketing')); ?>"
                                                                placeholder="Masukkan marketing">
                                                                <option value=""></option>
                                                                <option value="Marketing1">Marketing1</option>
                                                                <option value="Marketing2">Marketing2</option>
                                                                <option value="Marketing3">Marketing3</option>
                                                                <option value="Marketing4">Marketing4</option>
                                                            </select>
                                                            <?php $__errorArgs = ['marketing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-sm-12 col-lg-6">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">MARKING</h6>
                                                            <select
                                                                class="custom-select <?php $__errorArgs = ['marking'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="marking" value="<?php echo e(old('marking')); ?>"
                                                                placeholder="Masukkan marking">
                                                                <option value=""></option>
                                                                <option value="Marking1">Marking1</option>
                                                                <option value="Marking2">Marking2</option>
                                                                <option value="Marking3">Marking3</option>
                                                                <option value="Marking4">Marking4</option>
                                                            </select>
                                                            <?php $__errorArgs = ['marking'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">ITEM</h6>
                                                            <textarea class="form-control <?php $__errorArgs = ['item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="item" value="<?php echo e(old('item')); ?>"
                                                                placeholder="Masukkan item"></textarea>
                                                            <?php $__errorArgs = ['item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-2 col-sm-2 col-lg-2 col-xs-3">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">SIZE</h6>
                                                            <select
                                                                class="custom-select <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="size" value="<?php echo e(old('size')); ?>"
                                                                placeholder="Masukkan size">
                                                                <option value=""></option>
                                                                <option value="20">20</option>
                                                                <option value="40">40</option>
                                                                <option value="45">45</option>
                                                            </select>
                                                            <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-2 col-sm-2 col-lg-2 col-xs-2">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">QTY</h6>
                                                            <input type="number"
                                                                class="form-control <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="qty" value="<?php echo e(old('qty')); ?>" placeholder="">

                                                            <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3 col-sm-8 col-lg-3 col-xs-6">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">ASAL</h6>
                                                            <select
                                                                class="custom-select <?php $__errorArgs = ['asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="asal" value="<?php echo e(old('asal')); ?>"
                                                                placeholder="Masukkan asal">
                                                                <option value=""></option>
                                                                <option value="Jakarta">Jakartaaaa</option>
                                                                <option value="Bogor">Bogor</option>
                                                                <option value="Bekasi">Bekasi</option>
                                                                <option value="Etc">Etc</option>
                                                            </select>
                                                            <?php $__errorArgs = ['asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3 col-sm-8 col-lg-3 col-xs-6">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">PORT</h6>
                                                            <select
                                                                class="custom-select <?php $__errorArgs = ['port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="port" value="<?php echo e(old('port')); ?>"
                                                                placeholder="Masukkan port">

                                                                <option value=""></option>
                                                                <option value="Batam">Batam</option>
                                                                <option value="Medan">Medan</option>
                                                                <option value="Riau">Riau</option>
                                                                <option value="Jakarta">Jakarta</option>
                                                            </select>
                                                            <?php $__errorArgs = ['port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-1 col-sm-2 col-lg-2 col-xs-2">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">KURS</h6>
                                                            <select
                                                                class="custom-select <?php $__errorArgs = ['kurs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="mySelect" onchange="kali_2();" name="kurs"
                                                                value="<?php echo e(old('kurs')); ?>">
                                                                
                                                                <?php $__currentLoopData = $curs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($curs->id); ?>"
                                                                        nilai="<?php echo e($curs->nilai); ?>">
                                                                        <?php echo e($curs->mata_uang); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>

                                                
                                                <div class="row">
                                                    <div class="col-md-12 col-sm-12 col-lg-12">
                                                        <div class="form-group ">
                                                            <h6 class="font-weight-bold">HARGA CUSTOM</h6>

                                                            <input type="text" id="custom" onkeyup="sum();"
                                                                class="form-control  <?php $__errorArgs = ['harga_custom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                type-currency="IDR" name="harga_custom"
                                                                value="<?php echo e(old('harga_custom')); ?>"
                                                                placeholder="Masukkan Harga Custom">
                                                            <?php $__errorArgs = ['harga_custom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">HARGA KAPAL</h6>
                                                            <input type="text" id="kapal" onkeyup="sum();"
                                                                class="form-control <?php $__errorArgs = ['harga_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                type-currency="IDR" name="harga_kapal"
                                                                value="<?php echo e(old('harga_kapal')); ?>"
                                                                placeholder="Masukkan Harga kapal">
                                                            <?php $__errorArgs = ['harga_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-sm-6 col-lg-6">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">HARGA GUDANG</h6>
                                                            <input type="text" id="gudang" onkeyup="sum();"
                                                                class="form-control <?php $__errorArgs = ['harga_gudang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                type-currency="IDR" name="harga_gudang"
                                                                value="<?php echo e(old('harga_gudang')); ?>"
                                                                placeholder="Masukkan Harga Gudang">
                                                            <?php $__errorArgs = ['harga_gudang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6 col-lg-6 col-sm-6">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">TOTAL </h6>
                                                            <input type="text" id="total" onkeyup="sum();"
                                                                readonly
                                                                class="form-control <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                type-currency="IDR" name="total"
                                                                value="<?php echo e(old('total')); ?>">
                                                            <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-lg-6 col-sm-6">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">TOTAL INVOICE</h6>
                                                            <input type="text" id="hasil" onkeyup="kali_2();"
                                                                class="form-control <?php $__errorArgs = ['total_invoice_rmb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                type-currency="IDR" name="total_invoice_rmb"
                                                                value="<?php echo e(old('total_invoice_rmb')); ?>"
                                                                placeholder="Masukkan Total Invoice">

                                                            <?php $__errorArgs = ['total_invoice_rmb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-12 col-sm-12">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">RATE </h6>
                                                            <input type="text" id="rate_kurs" onkeyup="kali_2();"
                                                                readonly
                                                                class="form-control <?php $__errorArgs = ['rate_kurs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                type-currency="IDR" name="rate_kurs"
                                                                value="<?php echo e(old('rate_kurs')); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-12 col-sm-12">
                                                        <div class="form-group">
                                                            <h6 class="font-weight-bold">KETERANGAN</h6>
                                                            <textarea class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="keterangan"
                                                                value="<?php echo e(old('keterangan')); ?>" placeholder="Masukkan keterangan"></textarea>
                                                            <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger mt-2">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
                                                <a href="<?php echo e(route('orders.index')); ?>"
                                                    class="btn btn-md btn-primary">BACK</a>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        function kali_2() {
            var f = document.getElementById('mySelect').value;
            var select = document.forms['crt'].elements['kurs'];
            var hKurs = select.options[select.selectedIndex].getAttribute('nilai');
            //var hKurs = parseInt(f.replaceAll(',', ''))

            var g = document.getElementById('hasil').value;
            var hHasil = parseInt(g.replaceAll(',', ''))

            var result = parseInt(hKurs) * parseInt(hHasil);

            if (!isNaN(result)) {
                document.getElementById('rate_kurs').value = result;
            }
        }
        /*
                    $('#mySelect').on('change', function() {
                        var $option = $(this).find(':selected');
                        var nilai = $option.data('nilai');

                        var g = document.getElementById('hasil').value;
                        var hHasil = parseInt(g.replaceAll(',', ''))

                        var result = parseInt(nilai) * parseInt(hHasil);

                        if (!isNaN(result)) {
                            document.getElementById('rate_kurs').value = result;
                        }
                    });
        */
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravelv8/resources/views/dashboard/orders/create.blade.php ENDPATH**/ ?>